/**
 * 私聊
 */
const PRIVATE_CHAT = 1

/**
 * 群聊
 */
const GROUP_CHAT = 2
