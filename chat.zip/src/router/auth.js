export const AuthRouter = {
    path: '/auth',
    name: 'auth',
    redirect: '/auth/login',
    component: () => import('@/views/auth/layout.vue'),
    children: [
        {
            path: '/auth/register',
            meta: {
                title: '账号注册？',
                needLogin: false
            },
            component: () => import('@/views/auth/Register.vue')
        },
        {
            path: '/auth/login',
            meta: {
                title: '账号登录？',
                needLogin: false
            },
            component: () => import('@/views/auth/login.vue')
        },
        {
            path: '/auth/forget',
            meta: {
                title: '找回密码？',
                needLogin: false
            },
            component: () => import('@/views/auth/forget.vue')
        }
    ]
};
