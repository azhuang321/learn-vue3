<template>
  <div></div>
</template>

<script>
// 待开发
export default {
  data () {
    return {
      skins: [
        {
          theme: '',
          class: 'default',
          text: '默认'
        },
        {
          theme: '',
          class: 'red',
          text: '红色'
        },
        {
          theme: '',
          class: 'dark',
          text: '暗黑'
        },
        {
          theme: '',
          class: 'blue',
          text: '浅蓝'
        }
      ]
    };
  },
  created () {},
  methods: {}
};
</script>
<style lang="less" scoped></style>
