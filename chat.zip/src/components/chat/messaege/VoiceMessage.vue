<template>
  <div class="voice-message"></div>
</template>

<script>
export default {
  name: 'VoiceMessage',
  components: {},
  data () {
    return {};
  },
  methods: {},
  created () {}
};
</script>
<style lang="less" scoped></style>
