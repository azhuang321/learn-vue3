<template>
  <!-- 用户卡片消息 - 预留 -->
  <div></div>
</template>

<script>
export default {
  name: 'UserCardMessage',
  components: {},
  data () {
    return {};
  },
  computed: {},
  watch: {},
  methods: {},
  created () {}
};
</script>
<style lang="less" scoped></style>
