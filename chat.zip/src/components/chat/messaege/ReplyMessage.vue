<template>
  <div class="reply-message">这是回复的消息[预留]</div>
</template>

<script>
export default {
  name: 'ReplyMessage',
  data () {
    return {};
  },
  created () {},
  methods: {}
};
</script>
<style lang="less" scoped>
.reply-message {
  margin-top: 5px;
  min-height: 28px;
  background: #f7f1f1;
  line-height: 28px;
  font-size: 12px;
  padding: 0 10px;
  border-radius: 3px;
  color: #a7a2a2;
}
</style>
