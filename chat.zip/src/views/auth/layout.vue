<template>
    <el-container id="auth-container">
        <el-main>
            <div id="logo-name" class="animated slideInLeft">
                {{ $store.state.website_name }}
                logo-name
            </div>

            <router-view />

            <div class="copyright" v-html="$store.state.copyright"></div>
        </el-main>
    </el-container>

    <div class="fly-box">
        <div class="fly bg-fly-circle1"></div>
        <div class="fly bg-fly-circle2"></div>
        <div class="fly bg-fly-circle3"></div>
        <div class="fly bg-fly-circle4"></div>
    </div>
</template>
<script>

</script>
<style lang="scss" scoped>
:deep(..el-input__inner){
    border-radius: .01rem !important;
}

#auth-container{
    position: fixed;
    top: 0;
    right: 0;
    width: 100%;
    height: 100%;
    background-color: #f6f8fb;
}

#logo-name{
    font-size: .34rem;
    font-family: Times New Roman, Georgia, Serif, serif;
    color: #2196f3;
    margin-left: .2rem;
    margin-top: .2rem;
}


</style>
