
### 项目是基础版网易云信-uniapp版本
#### 由官方demo改造而来
 #### 官方demo下载地址:https://yunxin.163.com/sdk/app/29
 sdk版本:NIM_Web_NIM_miniapp_v8.4.0.js

imKey: '45c6af3c98409b18a84451215d0bdd6e'

#####此版本为基础版:只具备登录,最近聊天列表,及聊天窗口功能
账号可以去官网注册,或者在官方demo注册
这里提供我自己的账号可以试用:18589080607 123456