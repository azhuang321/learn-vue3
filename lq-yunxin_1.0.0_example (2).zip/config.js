const imgSrc = `https://wodan-idc.oss-cn-hangzhou.aliyuncs.com/miniProgram/test/jianzhike/`
const config = {
  baseUrl: `http://test-docker-www.shijianke.com`,
  baseUrlIm: `http://test-docker-im.shijianke.com`,
  upImageUrl: '/m/fileUpload/ossFileUpload',
  imgSrc: imgSrc,
  imKey: '45c6af3c98409b18a84451215d0bdd6e'
}

export default config